<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <a href="<?php echo e(route('solicitations.index')); ?>"><?php echo e(__('Solicitations')); ?></a>
            - <a href="<?php echo e(route('solicitations.create')); ?>" class="btn btn-primary">Crear</a>
        </h2>
     <?php $__env->endSlot(); ?>
    <div class="container-fluid">
        <table class="table table-striped table-hover">
            <thead class="table-dark">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Teléfono</th>
                    <th scope="col">Pareja</th>
                    <th scope="col">Descripción</th>
                    <th scope="col">Estatus</th>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('solicitations show')): ?>
                        <th scope="col">Historial</th>
                    <?php endif; ?>
                    <th scope="col">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $i = 1;
                ?>
                <?php $__empty_1 = true; $__currentLoopData = $solicitations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <th scope="row"><?php echo e($i); ?></th>
                        <td><?php echo e($solicitation->name_client); ?></td>
                        <td><?php echo e($solicitation->telephone_client); ?></td>
                        <td><?php echo e($solicitation->name_couple); ?></td>
                        <td><?php echo e(getSubString($solicitation->description, 20)); ?></td>
                        <td>
                            <?php echo getStatusSolicitation($solicitation->status); ?>

                        </td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('solicitations show')): ?>
                            <td>
                                <a href="<?php echo e(route('solicitations.historial', [$solicitation->id])); ?>">Ver <i
                                        class="bi bi-folder-symlink-fill"></i></a>
                            </td>
                        <?php endif; ?>
                        <td>
                            <?php echo $__env->make('components.table.actions', [
                            'params' => [$solicitation->id],
                            'showRoute' => 'solicitations.show',
                            'editRoute' => 'solicitations.edit',
                            'deleteRoute' => 'solicitations.destroy',
                            'skipShow' => current_user()->can('solicitations show'),
                            'skipEdit' => current_user()->can('solicitations edit'),
                            'skipDelete' => current_user()->can('solicitations delete')
                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </td>
                    </tr>
                    <?php
                        $i++;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center">
                            No se encontraron registros
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\laravel\divorces\resources\views/solicitations/index.blade.php ENDPATH**/ ?>