<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Ver Perfil de Usuario')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="container-fluid">
        <div class="row mb-3">
            <div class="col">
                <label for="firstname" class="form-label">Nombre</label>
                <div class="form-control"><?php echo e($user->profile->firstname); ?></div>
            </div>
            <div class="col">
                <label for="lastname" class="form-label">Apellido</label>
                <div class="form-control"><?php echo e($user->profile->lastname); ?></div>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col">
                <label for="phone" class="form-label">Teléfono</label>
                <div class="form-control"><?php echo e($user->profile->phone); ?></div>
            </div>
            <div class="col">
                <label for="email" class="form-label">Email</label>
                <div class="form-control"><?php echo e($user->email); ?></div>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col">
                <label for="country" class="form-label">País</label>
                <div class="form-control"><?php echo e($user->profile->country); ?></div>
            </div>
            <div class="col">
                <label for="state" class="form-label">Estado</label>
                <div class="form-control"><?php echo e($user->profile->state); ?></div>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col">
                <label for="city" class="form-label">Ciudad</label>
                <div class="form-control"><?php echo e($user->profile->city); ?></div>
            </div>
            <div class="col">
                <label for="street" class="form-label">Calle</label>
                <div class="form-control"><?php echo e($user->profile->street); ?></div>
            </div>
            <div class="col">
                <label for="zip" class="form-label">C.P.</label>
                <div class="form-control"><?php echo e($user->profile->zip); ?></div>
            </div>
        </div>
        <?php if(current_user()->hasRole('admin')): ?>
            <div class="mb-3">
                <label for="roles" class="form-label">Permisos</label>
                <br />
                <?php echo generateColumnsPermissions($user->permissions, 4, $user, true); ?>

            </div>
        <?php endif; ?>
        <a href="<?php echo e(route('users.edit', [$user->id])); ?>" class="btn btn-primary">Editar</a>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\laravel\divorces\resources\views/users/show.blade.php ENDPATH**/ ?>