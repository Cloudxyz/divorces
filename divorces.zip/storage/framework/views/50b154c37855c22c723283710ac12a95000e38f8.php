<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Edit Solicitation')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="container-fluid">
        <form action="<?php echo e(route('solicitations.update', [$solicitation->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="divorce_id" class="form-label">Tipo de Divorcio</label>
                <select class="form-select" id="divorce_id" name="divorce_id">
                    <option selected>Select Type of Divorce</option>
                    <?php $__currentLoopData = $typesDivorces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($type->id); ?>"
                            <?php echo e($solicitation->divorce_id == $type->id ? 'selected' : ''); ?>><?php echo e($type->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="name_client" class="form-label">Tu Nombre</label>
                <input type="text" class="form-control" id="name_client" name="name_client"
                    value="<?php echo e($solicitation->name_client); ?>">
            </div>
            <div class="mb-3">
                <label for="telephone_client" class="form-label">Tu Teléfono</label>
                <input type="text" class="form-control" id="telephone_client" name="telephone_client"
                    value="<?php echo e($solicitation->telephone_client); ?>">
            </div>
            <div class="mb-3">
                <label for="name_couple" class="form-label">Nombre de la Expareja</label>
                <input type="text" class="form-control" id="name_couple" name="name_couple"
                    value="<?php echo e($solicitation->name_couple); ?>">
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Descripción</label>
                <textarea class="form-control" placeholder="Descripción" id="description"
                    name="description"><?php echo e($solicitation->description); ?></textarea>
            </div>
            <div class="mb-3">
                <label for="status" class="form-label">Estatus</label>
                <select class="form-select" id="status" name="status">
                    <option selected>Select Type of Status</option>
                    <?php $__currentLoopData = $statusSoliciations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status->id); ?>"
                            <?php echo e($solicitation->status == $status->id ? 'selected' : ''); ?>><?php echo e($status->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </form>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\laravel\divorces\resources\views/public/solicitations/edit.blade.php ENDPATH**/ ?>