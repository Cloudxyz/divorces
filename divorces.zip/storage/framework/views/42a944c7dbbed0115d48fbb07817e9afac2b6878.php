<?php if (isset($component)) { $__componentOriginal95966b5bd427f0cdb41e997722ed36bfb128c893 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppPublicLayout::class, []); ?>
<?php $component->withName('app-public-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="container-fluid">
        <a href="<?php echo e(route('solicitations.create')); ?>">Crear Solicitación</a>
    </div>
 <?php if (isset($__componentOriginal95966b5bd427f0cdb41e997722ed36bfb128c893)): ?>
<?php $component = $__componentOriginal95966b5bd427f0cdb41e997722ed36bfb128c893; ?>
<?php unset($__componentOriginal95966b5bd427f0cdb41e997722ed36bfb128c893); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\laravel\divorces\resources\views/welcome.blade.php ENDPATH**/ ?>